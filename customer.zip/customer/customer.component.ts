import { Component, OnInit } from '@angular/core';
import { UserService } from '../_services/index';
declare var BMap: any;
declare var BMapGL: any;
@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.scss'],
  providers: [ ]
})

export class CustomerComponent implements OnInit {

  currentUser: any;

  constructor(private user: UserService) { }

  ngOnInit() {
    this.currentUser = this.user.getCurrentUser();
    // 引入百度地图
    const map = new BMap.Map('map');//创建地图实例
    map.centerAndZoom(new BMapGL.Point(116.404, 39.928), 9);
    map.enableScrollWheelZoom(true);
    // 创建点标记
    var marker1 = new BMapGL.Marker(new BMapGL.Point(116.436177,39.90608));
    var marker2 = new BMapGL.Marker(new BMapGL.Point(117.23186,38.996808));
    var marker3 = new BMapGL.Marker(new BMapGL.Point(116.827119,38.315173));
    var marker4 = new BMapGL.Marker(new BMapGL.Point(116.827119,38.315173));
    // 在地图上添加点标记
    map.addOverlay(marker1);
    map.addOverlay(marker2);
    map.addOverlay(marker3);
    map.addOverlay(marker4);
  }
}
