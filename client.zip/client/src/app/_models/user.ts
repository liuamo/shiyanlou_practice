export class User {
  userid: string;
  password: string;
  usertype: string;
  // firstName: string;
  // lastName: string;
}
