import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../_services/index';

@Component({
  selector: 'app-enroll',
  templateUrl: './enroll.component.html',
  styleUrls: ['./enroll.component.scss'],
  providers: []
})

export class EnrollComponent{
  model: any = {};
  loading = false;
  types: any[];

  constructor (private router: Router,private authService: AuthService) {
    this.types = ["零售商", "生产商", "托运人", "客户", "监管机构"] ;
  }

  enroll() {
    this.loading = true;
    this.authService.enroll(this.model).subscribe(data => {
      alert("注册成功。用户可以登录到他们的门户网站。");
      this.router.navigate(['/login']);
    }, error => {
      this.loading = false;
      console.log(JSON.stringify(error));
      alert("Enrollment failed: " + error['error']['message']);
    });
  }
}

